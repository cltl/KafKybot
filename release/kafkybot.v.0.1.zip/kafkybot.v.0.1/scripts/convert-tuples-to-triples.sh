java -Xmx812m -cp ../lib/vu.kafkybot.KafKybot-1.0-jar-with-dependencies.jar vu.kafkybot.ConvertTuplesToTriples --tuple-file "../example/bus-accident.ont.dep.kaf.sem.tpl"  --first-element event
java -Xmx812m -cp ../lib/vu.kafkybot.KafKybot-1.0-jar-with-dependencies.jar vu.kafkybot.ConvertTuplesToTriples --tuple-file "../example/bus-accident.ont.dep.kaf.syn.tpl"  --first-element event
